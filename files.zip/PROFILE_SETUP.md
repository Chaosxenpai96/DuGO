# Profile feature – where everything goes

## 1. NEW files  (create folder `profile` and put all 9 files inside)
`app/src/main/java/com/example/dugo/profile/`

| File | What it is |
|---|---|
| ProfileModels.kt | Data classes (UserProfile, DonationRecord) + date/eligibility helpers |
| ProfileStore.kt | Saves profile + photo on the phone (SharedPreferences, no new libraries) |
| ProfileUi.kt | Shared UI pieces (sub-screen layout, cards, switches, avatar, dialogs) |
| ProfileScreen.kt | **The Profile tab** (your design) + navigation to sub-screens |
| AccountInfoScreen.kt | Account information (name, username, phone) |
| DonationHistoryScreen.kt | Donation history, add/delete, "can donate again on…" |
| LocationSettingsScreen.kt | Location text, area quick-picks, share on map, radius, permission |
| PrivacySecurityScreen.kt | Privacy switches, change password, log out, delete account |
| UpdateProfileScreen.kt | "Update donor profile" button (blood type + availability) |

## 2. EXISTING files you must edit  (search for `[PROFILE]`)
1. `app/src/main/java/com/example/dugo/MainActivity.kt` – replace with the provided one
   (adds `Screen.Profile`, loads/saves the profile, opens Profile from the tab/header icon).
2. `app/src/main/java/com/example/dugo/home/HomeScreenMap.kt` – 3 small changes:
   - `private fun HomeHeader(...)`  ->  `internal fun HomeHeader(..., location: String = "Dalaguete, Cebu")`
   - `Text("Dalaguete, Cebu", ...)` inside it  ->  `Text(location, ...)`
   - `private fun BottomNav(...)`  ->  `internal fun BottomNav(...)`
3. `app/src/main/AndroidManifest.xml` – add under the FINE location line:
   `<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />`

No changes to build.gradle – only libraries you already have.

## 3. Still TODO (needs your backend)
Search the code for `TODO (backend)`: saving edits online, username-taken check,
real password change, deleting the account on the server.
